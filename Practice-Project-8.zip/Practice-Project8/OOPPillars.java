// Class representing a Bank Account
class BankAccount {
    private String accountNumber;
    private double balance;

    // Constructor to initialize the account
    public BankAccount(String accountNumber, double initialBalance) {
        this.accountNumber = accountNumber;
        this.balance = initialBalance;
    }

    // Encapsulation: Getter for account number
    public String getAccountNumber() {
        return accountNumber;
    }

    // Encapsulation: Getter for balance
    public double getBalance() {
        return balance;
    }

    // Encapsulation: Method to deposit money
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited $" + amount + " into account " + accountNumber);
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }

    // Encapsulation: Method to withdraw money
    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("Withdrawn $" + amount + " from account " + accountNumber);
        } else {
            System.out.println("Invalid withdrawal amount.");
        }
    }
}

// Inheritance: Class representing a Savings Account, which inherits from BankAccount
class SavingsAccount extends BankAccount {
    private double interestRate;

    public SavingsAccount(String accountNumber, double initialBalance, double interestRate) {
        super(accountNumber, initialBalance);
        this.interestRate = interestRate;
    }

    // Polymorphism: Override the withdraw method to apply interest on withdrawal
    @Override
    public void withdraw(double amount) {
        super.withdraw(amount); // Call the parent class method
        applyInterest();
    }

    // Abstraction: Method to apply interest
    private void applyInterest() {
        double balance = getBalance();
        double interest = balance * interestRate / 100;
        deposit(interest);
        System.out.println("Interest applied: $" + interest);
    }
}

public class OOPPillars {
    public static void main(String[] args) {
        // Create a BankAccount object
        BankAccount account1 = new BankAccount("A12345", 1000.0);

        // Deposit and withdraw from the BankAccount
        account1.deposit(500.0);
        account1.withdraw(200.0);

        System.out.println("Account " + account1.getAccountNumber() + " balance: $" + account1.getBalance());

        // Create a SavingsAccount object
        SavingsAccount account2 = new SavingsAccount("S67890", 2000.0, 3.0);

        // Deposit and withdraw from the SavingsAccount
        account2.deposit(1000.0);
        account2.withdraw(500.0);

        System.out.println("Account " + account2.getAccountNumber() + " balance: $" + account2.getBalance());
    }
}
