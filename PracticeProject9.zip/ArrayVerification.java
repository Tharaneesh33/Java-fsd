public class ArrayVerification {
    public static void main(String[] args) {
        // Declare and initialize an array of integers
        int[] numbers = { 1, 2, 3, 4, 5 };

        // Access and print elements of the array
        System.out.println("Array Elements:");
        for (int i = 0; i < numbers.length; i++) {
            System.out.println("Element at index " + i + ": " + numbers[i]);
        }

        // Calculate the sum of array elements
        int sum = 0;
        for (int number : numbers) {
            sum += number;
        }
        System.out.println("Sum of Array Elements: " + sum);

        // Declare and initialize an array of strings
        String[] fruits = { "Apple", "Banana", "Cherry", "Date", "Fig" };

        // Access and print elements of the string array
        System.out.println("\nString Array Elements:");
        for (int i = 0; i < fruits.length; i++) {
            System.out.println("Element at index " + i + ": " + fruits[i]);
        }

        // Find the length of the string array
        int arrayLength = fruits.length;
        System.out.println("Length of String Array: " + arrayLength);

        // Search for a specific element in the string array
        String searchFruit = "Cherry";
        boolean found = false;
        for (String fruit : fruits) {
            if (fruit.equals(searchFruit)) {
                found = true;
                break;
            }
        }
        if (found) {
            System.out.println(searchFruit + " found in the string array.");
        } else {
            System.out.println(searchFruit + " not found in the string array.");
        }
    }
}
