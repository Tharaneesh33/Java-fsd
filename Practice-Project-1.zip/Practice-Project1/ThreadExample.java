// Extending the Thread class
class MyThread1 extends Thread {
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println("Thread 1: " + i);
            try {
                Thread.sleep(1000); // Sleep for 1 second
            } catch (InterruptedException e) {
                System.out.println(e);
            }
        }
    }
}

// Implementing the Runnable interface
class MyThread2 implements Runnable {
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println("Thread 2: " + i);
            try {
                Thread.sleep(1000); // Sleep for 1 second
            } catch (InterruptedException e) {
                System.out.println(e);
            }
        }
    }
}

public class ThreadExample {
    public static void main(String[] args) {
        // Create a thread by extending the Thread class
        MyThread1 thread1 = new MyThread1();

        // Create a thread by implementing the Runnable interface
        MyThread2 thread2 = new MyThread2();
        Thread t2 = new Thread(thread2);

        // Start both threads
        thread1.start();
        t2.start();
    }
}

