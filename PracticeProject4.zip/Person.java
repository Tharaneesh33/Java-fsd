public class Person {
    private String name;
    private int age;

    // Default Constructor
    public Person() {
        this.name = "Unknown";
        this.age = 0;
    }

    // Parameterized Constructor
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Copy Constructor
    public Person(Person otherPerson) {
        this.name = otherPerson.name;
        this.age = otherPerson.age;
    }

    // Method to display person information
    public void display() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
    }

    public static void main(String[] args) {
        // Create a person using the default constructor
        Person person1 = new Person();
        System.out.println("Person 1 (Default Constructor):");
        person1.display();
        System.out.println();

        // Create a person using the parameterized constructor
        Person person2 = new Person("Alice", 30);
        System.out.println("Person 2 (Parameterized Constructor):");
        person2.display();
        System.out.println();

        // Create a new person by copying person2 using the copy constructor
        Person person3 = new Person(person2);
        System.out.println("Person 3 (Copy Constructor):");
        person3.display();
        System.out.println();

        // Modify the copied person's information
        person3.name = "Bob";
        person3.age = 25;

        System.out.println("After modifying Person 3:");
        System.out.println("Person 2:");
        person2.display();
        System.out.println("Person 3:");
        person3.display();
    }
}
