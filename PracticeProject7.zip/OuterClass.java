public class OuterClass {
    private int outerField = 10;

    // Inner class
    public class InnerClass {
        public void displayOuterField() {
            System.out.println("Value of outerField from InnerClass: " + outerField);
        }
    }

    // Static inner class
    public static class StaticInnerClass {
        public void displayMessage() {
            System.out.println("StaticInnerClass is a static inner class.");
        }
    }

    public static void main(String[] args) {
        // Create an instance of the outer class
        OuterClass outerObj = new OuterClass();

        // Create an instance of the inner class using the outer class instance
        OuterClass.InnerClass innerObj = outerObj.new InnerClass();
        innerObj.displayOuterField();

        // Create an instance of the static inner class directly
        OuterClass.StaticInnerClass staticInnerObj = new OuterClass.StaticInnerClass();
        staticInnerObj.displayMessage();
    }
}
