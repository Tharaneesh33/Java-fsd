import java.util.LinkedList;
import java.util.Queue;

public class QueueExample {
    public static void main(String[] args) {
        // Create a queue
        Queue<Integer> queue = new LinkedList<>();

        // Enqueue elements into the queue
        queue.offer(10);
        queue.offer(20);
        queue.offer(30);
        queue.offer(40);
        queue.offer(50);

        // Display the queue
        System.out.println("Queue: " + queue);

        // Dequeue elements from the queue
        int dequeuedElement = queue.poll();
        System.out.println("Dequeued Element: " + dequeuedElement);

        // Display the updated queue
        System.out.println("Queue after dequeue: " + queue);

        // Peek at the front element without removing it
        int frontElement = queue.peek();
        System.out.println("Front Element (Peek): " + frontElement);

        // Check if the queue is empty
        boolean isEmpty = queue.isEmpty();
        System.out.println("Is the queue empty? " + isEmpty);
    }
}
