public class Calculator {
    // Method to add two numbers
    public int add(int num1, int num2) {
        return num1 + num2;
    }

    // Method to subtract two numbers
    public int subtract(int num1, int num2) {
        return num1 - num2;
    }

    // Method to multiply two numbers
    public int multiply(int num1, int num2) {
        return num1 * num2;
    }

    // Method to divide two numbers
    public double divide(double num1, double num2) {
        if (num2 == 0) {
            System.out.println("Error: Division by zero is not allowed.");
            return Double.NaN; // Not-a-Number result for division by zero
        }
        return num1 / num2;
    }

    // Main method to demonstrate method calls
    public static void main(String[] args) {
        Calculator calculator = new Calculator();

        // Calling methods and printing the results
        int sum = calculator.add(5, 3);
        System.out.println("5 + 3 = " + sum);

        int difference = calculator.subtract(8, 2);
        System.out.println("8 - 2 = " + difference);

        int product = calculator.multiply(4, 6);
        System.out.println("4 * 6 = " + product);

        double quotient = calculator.divide(10.0, 2.0);
        System.out.println("10.0 / 2.0 = " + quotient);

        // Attempting to divide by zero
        double invalidQuotient = calculator.divide(5.0, 0.0);
        System.out.println("5.0 / 0.0 = " + invalidQuotient); // Will print an error message

        // Calling methods with different arguments
        int result1 = calculator.add(10, 20);
        int result2 = calculator.add(30, 40, 50); // Overloaded method
        System.out.println("10 + 20 = " + result1);
        System.out.println("30 + 40 + 50 = " + result2);
    }

    // Overloaded method to add three numbers
    public int add(int num1, int num2, int num3) {
        return num1 + num2 + num3;
    }
}
