import java.util.Arrays;

public class FourthSmallestElement {
    public static void main(String[] args) {
        int[] unsortedList = { 12, 45, 9, 56, 34, 1, 78, 8, 23 };
        int k = 4; // Find the fourth smallest element

        if (k <= unsortedList.length) {
            int fourthSmallest = findKthSmallest(unsortedList, k);
            System.out.println("The fourth smallest element is: " + fourthSmallest);
        } else {
            System.out.println("The list does not have a fourth smallest element.");
        }
    }

    public static int findKthSmallest(int[] arr, int k) {
        Arrays.sort(arr); // Sort the array in ascending order
        return arr[k - 1]; // Return the kth smallest element (0-based index)
    }
}
