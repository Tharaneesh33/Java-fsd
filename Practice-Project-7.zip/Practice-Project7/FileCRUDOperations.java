import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileCRUDOperations {
    public static void main(String[] args) {
        // Specify the file name
        String fileName = "example.txt";

        // Create a file
        createFile(fileName);

        // Write data to the file
        writeToFile(fileName, "This is a sample text.");

        // Read data from the file
        readFromFile(fileName);

        // Update data in the file
        updateFile(fileName, "Updated content.");

        // Read the updated data
        readFromFile(fileName);

        // Delete the file
        deleteFile(fileName);
    }

    // Create a file
    public static void createFile(String fileName) {
        try {
            File file = new File(fileName);
            if (file.createNewFile()) {
                System.out.println("File created: " + file.getName());
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Write data to the file
    public static void writeToFile(String fileName, String data) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            writer.write(data);
            System.out.println("Data written to the file.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Read data from the file
    public static void readFromFile(String fileName) {
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            System.out.println("Reading from the file:");
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Update data in the file
    public static void updateFile(String fileName, String newData) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            writer.write(newData);
            System.out.println("Data updated in the file.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Delete the file
    public static void deleteFile(String fileName) {
        File file = new File(fileName);
        if (file.delete()) {
            System.out.println("File deleted: " + fileName);
        } else {
            System.out.println("Failed to delete the file.");
        }
    }
}
