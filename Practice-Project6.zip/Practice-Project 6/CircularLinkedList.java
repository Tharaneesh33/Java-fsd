class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

public class CircularLinkedList {
    Node head;

    CircularLinkedList() {
        head = null;
    }

    void insertSorted(int newData) {
        Node newNode = new Node(newData);

        if (head == null) {
            // If the list is empty, make newNode the only node and point to itself
            newNode.next = newNode;
            head = newNode;
        } else if (newData <= head.data) {
            // If the new data is less than or equal to the head's data, insert at the beginning
            newNode.next = head;
            Node current = head;
            while (current.next != head) {
                current = current.next;
            }
            current.next = newNode;
            head = newNode;
        } else {
            // Find the correct position to insert while keeping the list sorted
            Node current = head;
            while (current.next != head && current.next.data < newData) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    void display() {
        if (head == null) {
            System.out.println("Circular Linked List is empty.");
            return;
        }

        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }

    public static void main(String[] args) {
        CircularLinkedList circularLinkedList = new CircularLinkedList();

        circularLinkedList.insertSorted(5);
        circularLinkedList.insertSorted(2);
        circularLinkedList.insertSorted(8);
        circularLinkedList.insertSorted(3);

        System.out.println("Circular Linked List:");
        circularLinkedList.display();
    }
}
