import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class MapVerification {
    public static void main(String[] args) {
        // Create a HashMap to store country and its capital
        Map<String, String> hashMap = new HashMap<>();

        // Add data to the HashMap
        hashMap.put("USA", "Washington, D.C.");
        hashMap.put("Canada", "Ottawa");
        hashMap.put("France", "Paris");
        hashMap.put("Germany", "Berlin");

        // Print the HashMap
        System.out.println("HashMap (Unordered):");
        printMap(hashMap);

        // Create a TreeMap to store country and its capital (sorted by keys)
        Map<String, String> treeMap = new TreeMap<>(hashMap);

        // Print the TreeMap
        System.out.println("\nTreeMap (Ordered by Keys):");
        printMap(treeMap);
    }

    // Helper method to print a map
    public static void printMap(Map<String, String> map) {
        for (Map.Entry<String, String> entry : map.entrySet()) {
            String country = entry.getKey();
            String capital = entry.getValue();
            System.out.println(country + ": " + capital);
        }
    }
}
