import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexVerification {
    public static void main(String[] args) {
        // Sample text for regex verification
        String text = "Hello, my email is john@example.com. Please contact me.";

        // Regular expression to match email addresses
        String regex = "\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}\\b";

        // Compile the regex pattern
        Pattern pattern = Pattern.compile(regex);

        // Create a Matcher object to find matches in the text
        Matcher matcher = pattern.matcher(text);

        // Find and print all email addresses in the text
        System.out.println("Email Addresses in Text:");
        while (matcher.find()) {
            String email = matcher.group();
            System.out.println(email);
        }

        // Replace all email addresses with "<email>"
        String maskedText = matcher.replaceAll("<email>");
        System.out.println("\nMasked Text:");
        System.out.println(maskedText);

        // Check if the text contains a valid phone number (10 digits)
        String phoneNumberText = "My phone number is 123-456-7890.";
        String phoneRegex = "\\b\\d{3}-\\d{3}-\\d{4}\\b";
        Pattern phonePattern = Pattern.compile(phoneRegex);
        Matcher phoneMatcher = phonePattern.matcher(phoneNumberText);
        if (phoneMatcher.find()) {
            System.out.println("\nValid Phone Number Found: " + phoneMatcher.group());
        } else {
            System.out.println("\nNo valid phone number found.");
        }
    }
}
