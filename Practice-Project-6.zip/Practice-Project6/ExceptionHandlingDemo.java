public class ExceptionHandlingDemo {
    public static void main(String[] args) {
        try {
            // Division by zero
            int result = 10 / 0;
        } catch (ArithmeticException e) {
            // Catching and handling ArithmeticException
            System.err.println("ArithmeticException: " + e.getMessage());
        }

        try {
            // ArrayIndexOutOfBoundsException
            int[] arr = new int[5];
            arr[10] = 42;
        } catch (ArrayIndexOutOfBoundsException e) {
            // Catching and handling ArrayIndexOutOfBoundsException
            System.err.println("ArrayIndexOutOfBoundsException: " + e.getMessage());
        }

        try {
            // String to integer conversion
            String str = "Hello";
            int num = Integer.parseInt(str);
        } catch (NumberFormatException e) {
            // Catching and handling NumberFormatException
            System.err.println("NumberFormatException: " + e.getMessage());
        } finally {
            // Code in the finally block always executes
            System.out.println("Inside the finally block.");
        }

        // Code continues to execute after exception handling
        System.out.println("Program continues after exception handling.");
    }
}

