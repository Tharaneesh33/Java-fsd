// Define a common interface with a default method
interface Animal {
    default void speak() {
        System.out.println("Animal speaks.");
    }
}

// Define two interfaces that extend the common interface
interface Cat extends Animal {
    default void speak() {
        System.out.println("Cat meows.");
    }
}

interface Dog extends Animal {
    default void speak() {
        System.out.println("Dog barks.");
    }
}

// Create a class that implements both Cat and Dog interfaces
class Pet implements Cat, Dog {
    // Resolve the diamond problem by providing a specific implementation of the speak method
    @Override
    public void speak() {
        System.out.println("Pet makes a sound.");
    }
}

public class DiamondProblem {
    public static void main(String[] args) {
        Pet pet = new Pet();
        pet.speak(); // Calls the Pet class implementation
    }
}

