// Custom exception class
class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}

public class CustomExceptions {
    // Method that throws an exception
    public static void throwException() throws CustomException {
        System.out.println("Inside throw Exception method.");
        throw new CustomException("This is a custom exception.");
    }

    public static void main(String[] args) {
        try {
            // Calling a method that throws an exception
            throwException();
        } catch (CustomException e) {
            // Catching the custom exception
            System.err.println("Caught CustomException: " + e.getMessage());
        } finally {
            // Code in the finally block always executes
            System.out.println("Inside the finally block.");
        }

        // Code continues to execute after exception handling
        System.out.println("Program continues after exception handling.");
    }
}
