public class ExponentialSearch {
    // Exponential search function
    public static int exponentialSearch(int[] arr, int target) {
        int length = arr.length;

        // If the target element is the first element
        if (arr[0] == target) {
            return 0;
        }

        // Find the range for binary search
        int i = 1;
        while (i < length && arr[i] <= target) {
            i *= 2;
        }

        // Perform binary search within the identified range
        return binarySearch(arr, target, i / 2, Math.min(i, length - 1));
    }

    // Binary search function
    public static int binarySearch(int[] arr, int target, int low, int high) {
        while (low <= high) {
            int mid = low + (high - low) / 2;

            if (arr[mid] == target) {
                return mid;
            }

            if (arr[mid] < target) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }

        return -1; // Element not found
    }

    public static void main(String[] args) {
        int[] arr = { 2, 4, 6, 8, 10, 12, 14, 16, 18, 20 };
        int target = 10;
        int result = exponentialSearch(arr, target);

        if (result != -1) {
            System.out.println("Element " + target + " found at index " + result);
        } else {
            System.out.println("Element " + target + " not found in the array");
        }
    }
}
