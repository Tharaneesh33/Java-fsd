public class RightRotateArray {
    public static void main(String[] args) {
        int[] originalArray = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        int k = 5; // Number of steps to rotate

        // Ensure k is within the range of the array length
        k = k % originalArray.length;

        int[] rotatedArray = rightRotate(originalArray, k);

        System.out.println("Original Array: ");
        printArray(originalArray);

        System.out.println("Right Rotated Array by " + k + " steps: ");
        printArray(rotatedArray);
    }

    // Function to right rotate an array by k steps
    public static int[] rightRotate(int[] arr, int k) {
        int n = arr.length;
        int[] rotated = new int[n];

        for (int i = 0; i < n; i++) {
            rotated[(i + k) % n] = arr[i];
        }

        return rotated;
    }

    // Function to print an array
    public static void printArray(int[] arr) {
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}
