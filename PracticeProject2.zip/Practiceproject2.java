public class Practiceproject2 {
    
}
