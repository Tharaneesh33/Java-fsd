public class ExceptionHandling {
    public static void main(String[] args) {
        try {
            // Code that may cause an exception
            int numerator = 10;
            int denominator = 0;
            int result = numerator / denominator; // This will throw an ArithmeticException
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            // Catch and handle the exception
            System.err.println("An ArithmeticException occurred: " + e.getMessage());
            e.printStackTrace();
        } finally {
            // Code in the finally block always executes
            System.out.println("Inside the finally block.");
        }

        // Code continues to execute after exception handling
        System.out.println("Program continues after exception handling.");
    }
}
