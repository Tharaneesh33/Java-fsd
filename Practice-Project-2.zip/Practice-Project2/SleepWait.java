class MyThread extends Thread {
    private final Object lock;

    public MyThread(Object lock) {
        this.lock = lock;
    }

    public void run() {
        synchronized (lock) {
            System.out.println("Thread " + Thread.currentThread().getId() + " is entering the critical section.");
            try {
                // Demonstrate sleep()
                System.out.println("Thread " + Thread.currentThread().getId() + " is going to sleep for 2 seconds.");
                Thread.sleep(2000); // Sleep for 2 seconds
                System.out.println("Thread " + Thread.currentThread().getId() + " woke up from sleep.");

                // Demonstrate wait() and notify()
                System.out.println("Thread " + Thread.currentThread().getId() + " is waiting.");
                lock.wait(); // Wait until notified
                System.out.println("Thread " + Thread.currentThread().getId() + " has been notified.");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("Thread " + Thread.currentThread().getId() + " is leaving the critical section.");
        }
    }
}

public class SleepWait {
    public static void main(String[] args) {
        Object lock = new Object();

        MyThread thread1 = new MyThread(lock);
        MyThread thread2 = new MyThread(lock);

        thread1.start();
        thread2.start();

        // Allow threads to run for a while
        try {
            Thread.sleep(3000); // Sleep for 3 seconds
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        synchronized (lock) {
            // Demonstrate notify()
            System.out.println("Main thread is notifying one of the waiting threads.");
            lock.notify(); // Notify one of the waiting threads
        }
    }
}

