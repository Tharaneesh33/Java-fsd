

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/UpdateServletCrossing")
public class UpdateServletCrossing extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form parameters
        String name = request.getParameter("name");
        String address = request.getParameter("address");
        String landmark = request.getParameter("landmark");
        String schedule = request.getParameter("schedule");
        String incharge = request.getParameter("incharge");
        String status = request.getParameter("status");

        // JDBC connection parameters
        String jdbcUrl = "jdbc:mysql://localhost:3306/data";
        String dbUser = "root";
        String dbPassword = "Root@123";
        
        Connection conn = null;

        try {
            // Initialize the database connection
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);
            
         
            String updateCrossingQuery = "UPDATE crossings SET address=?, landmark=?, schedule=?, incharge=?, status=? WHERE name=?";
            PreparedStatement preparedStatement = conn.prepareStatement(updateCrossingQuery);
            preparedStatement.setString(1, address);
            preparedStatement.setString(2, landmark);
            preparedStatement.setString(3, schedule);
            preparedStatement.setString(4, incharge);
            preparedStatement.setString(5, status);
            preparedStatement.setString(6, name);
            
            
            int rowsAffected = preparedStatement.executeUpdate();
            
            if (rowsAffected > 0) {
               
                response.sendRedirect("admin.html");
            } else {
          
                response.sendRedirect("admin.html?error=true");
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
