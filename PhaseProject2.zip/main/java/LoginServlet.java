
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        
        // JDBC connection parameters
        String jdbcUrl = "jdbc:mysql://localhost:3306/user";	
        String dbUser = "root";
        String dbPassword = "Root@123";
        
        Connection conn = null;
        boolean validCredentials = false;

        try {
            // Initialize the database connection
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);
            
            // SQL query to check user credentials
            String checkCredentialsQuery = "SELECT * FROM users WHERE email=? AND password=?";
            PreparedStatement preparedStatement = conn.prepareStatement(checkCredentialsQuery);
            preparedStatement.setString(1, email);
            preparedStatement.setString(2, password);
            
            // Execute the SQL query
            ResultSet resultSet = preparedStatement.executeQuery();
            
            // If a matching user is found, credentials are valid
            if (resultSet.next()) {
                validCredentials = true;
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            // Handle database errors here
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        if (validCredentials) {
            response.sendRedirect("main.html");
        } else {
            response.sendRedirect("login.html?error=true");
        }
    }
}

