

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DeleteCrossingServlet")
public class DeleteCrossingServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       
       
        String landmark = request.getParameter("landmark");
        String schedule = request.getParameter("schedule");
        String incharge = request.getParameter("incharge");
        String status = request.getParameter("status");
       
        
        String jdbcUrl = "jdbc:mysql://localhost:3306/data";
        String dbUser = "root";
        String dbPassword = "Root@123";
        
        Connection conn = null;

        try {
            // Initialize the database connection
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);
            
            
            String deleteCrossingQuery = "DELETE FROM railways WHERE landmark = ?, schedule= ?,incharge = ?,status = ?,";
            PreparedStatement preparedStatement = conn.prepareStatement(deleteCrossingQuery);
           
            preparedStatement.setString(1, landmark);
            preparedStatement.setString(2, schedule);
            preparedStatement.setString(3, incharge);
            preparedStatement.setString(4, status);
            
           
            int rowsAffected = preparedStatement.executeUpdate();
            
            if (rowsAffected > 0) {
              
                response.sendRedirect("admin.html");
            } else {
               
                response.sendRedirect("admin.html?error=true");
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            // Handle database errors here
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
